/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author Roble
 */
public class Electrodomestico {
    protected Float precio;
    protected String color;
    protected Character consumoEnergetico;
    protected Float peso;

    public Electrodomestico() {
    }

    public Electrodomestico(Float precio, String color, Character consumoEnergetico, Float peso) {
        this.precio = precio;
        this.color = color;
        this.consumoEnergetico = consumoEnergetico;
        this.peso = peso;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Character getConsumoEnergetico() {
        return consumoEnergetico;
    }

    public void setConsumoEnergetico(Character consumoEnergetico) {
        this.consumoEnergetico = consumoEnergetico;
    }

    public Float getPeso() {
        return peso;
    }

    public void setPeso(Float peso) {
        this.peso = peso;
    }
    
    private void comprobarConsumoEnergetico(Character letra){
        if (!letra.equals('A')||!letra.equals('B')||!letra.equals('C')||!letra.equals('D')||!letra.equals('E')||!letra.equals('F')) {
            consumoEnergetico = 'F';
        }
    }
}
