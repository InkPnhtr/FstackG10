
package Enumeraciones;

public enum Raza {
   OBEJERO,PITBULL,CANICHE; 
   
}
