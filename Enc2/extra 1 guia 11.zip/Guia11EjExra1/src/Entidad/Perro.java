package Entidad;

import Enumeraciones.Raza;

public class Perro {

    private String nombre;
    private int edad;
    private String tamaño;
    private Raza raza;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public Raza getRaza() {
        return raza;
    }

    public void setRaza(Raza raza) {
        this.raza = raza;
    }

    public Perro(String nombre, int edad, String tamaño, Raza raza) {
        this.nombre = nombre;
        this.edad = edad;
        this.tamaño = tamaño;
        this.raza = raza;
    }

    public Perro() {
    }
    
}
