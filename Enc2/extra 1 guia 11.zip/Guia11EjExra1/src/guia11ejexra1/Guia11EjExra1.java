
package guia11ejexra1;

import Entidad.Perro;
import Entidad.Persona;
import Enumeraciones.Raza;
import java.util.ArrayList;
import java.util.Scanner;

public class Guia11EjExra1 {
static Scanner leer = new Scanner(System.in).useDelimiter("\n");
    public static void main(String[] args) {
        ArrayList<Perro> perritos = new ArrayList();
        ArrayList<Persona> personas = new ArrayList();
        Perro per;
        Persona pers;
            for (int i = 0; i < 3; i++) {
                System.out.println("Ingrese nombre del perro");
                String nombre = leer.next();
                System.out.println("Ingrese edad del perro");
                int edad = leer.nextInt();
                System.out.println("Ingrese el tamaño");
                String tamanio = leer.next();
                perritos.add(new Perro(nombre,edad,tamanio,Raza.PITBULL));
            
            }
        for (int i = 0; i < 3; i++) {
                System.out.println("Ingrese nombre");
                String nombre = leer.next();
                System.out.println("Ingrese apellido");
                String apellido = leer.next();
                System.out.println("Ingrese edad");
                int edad = leer.nextInt();
                System.out.println("ingrese dni");
                int dni = leer.nextInt();
                personas.add(new Persona(nombre,apellido,edad,dni));
                System.out.println(perritos.toString());
            }
        

    }
    
}
