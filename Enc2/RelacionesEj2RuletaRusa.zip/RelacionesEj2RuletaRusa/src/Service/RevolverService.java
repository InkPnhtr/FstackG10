/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entidades.Revolver;
import java.util.Objects;
import java.util.Scanner;

/**
 *
 * @author Peluso
 */
public class RevolverService {

    Scanner leer = new Scanner(System.in);

    public void llenarRevolver(Revolver r) {
        Integer posActual;
        posActual = (int) (Math.random() * 6+1);

        Integer posAgua = (int) (Math.random() * 6+1);

        r.setPosActual(posActual);
        r.setPosAgua(posAgua);

    }

    public boolean mojar(Revolver r) {
        boolean moja = false;
        if (Objects.equals(r.getPosAgua(), r.getPosActual())) {
            moja = true;
        }
        return moja;

    }

    public void siguienteChorro(Revolver r) {

        if (r.getPosActual() == 6) {
            r.setPosActual(1);

        } else {
            r.setPosActual(r.getPosActual() + 1);
        }

    }

    public void mostrar(Revolver r) {
        System.out.println(r.toString());
    }
}
