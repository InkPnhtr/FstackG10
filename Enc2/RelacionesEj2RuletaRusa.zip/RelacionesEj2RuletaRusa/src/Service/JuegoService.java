/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entidades.Juego;
import Entidades.Jugador;
import Entidades.Revolver;
import java.util.ArrayList;

/**
 *
 * @author Roble
 */
public class JuegoService {

    Juego game = new Juego();

    public void llenarJuego(ArrayList<Jugador> jugadores, Revolver r) {
        game.setJugadores(jugadores);
        game.setRevolver(r);

    }

    public void ronda(ArrayList<Jugador> jugadores, JugadorService js, Revolver r, RevolverService rs) {

        for (Jugador aux : jugadores) {
            boolean terminoJuego = js.disparo(r, rs, aux);

            if (terminoJuego) {
                System.out.println("Termino el juego, el jugador mojado es " + aux.getNombre());
            } else {
                System.out.println(aux.getNombre() + " se salvo");
                System.out.println("siguiente jugador...");
            }
        }

    }
}
