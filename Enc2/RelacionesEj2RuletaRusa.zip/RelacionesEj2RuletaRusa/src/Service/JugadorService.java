/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entidades.Jugador;
import Entidades.Revolver;

/**
 *
 * @author Roble
 */
public class JugadorService {

    public boolean disparo(Revolver r, RevolverService rs, Jugador j) {
        boolean disparoMoja = false;
        boolean mojado = rs.mojar(r);

        if (mojado) {
            j.setMojado(true);
            disparoMoja = true;
        } else {
            rs.siguienteChorro(r);
        }
        return disparoMoja;
    }
}
