/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relacionesej2ruletarusa;

import Entidades.Jugador;
import Entidades.Revolver;
import Service.JuegoService;
import Service.JugadorService;
import Service.RevolverService;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Peluso
 */
public class RelacionesEj2RuletaRusa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RevolverService rs = new RevolverService();
        Revolver r = new Revolver();
        JugadorService js = new JugadorService();
        JuegoService jugar = new JuegoService();
        Scanner input = new Scanner(System.in);
        
        ArrayList<Jugador> jugadores = new ArrayList();

        System.out.println("Se va a iniciar un juego. Seleccione la cantidad de jugadores:");
        int cantidadJugadores = input.nextInt();
        if (cantidadJugadores<1||cantidadJugadores>6) {
            cantidadJugadores=6;
        }
        for (int i = 0; i < cantidadJugadores; i++) {
            Jugador a = new Jugador(i + 1);
            jugadores.add(a);
        }
        
        rs.llenarRevolver(r);
        rs.mostrar(r);
        jugar.llenarJuego(jugadores, r);
        jugar.ronda(jugadores, js, r, rs);
        
        
    }
    
}
